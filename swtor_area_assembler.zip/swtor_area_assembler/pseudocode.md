types:

gr2 (mesh and multi-mesh)

DIRECT CONVERSIONS
mag to gr2
spn to plc gr2
spn to plc to dyn single gr2

EMPTY OR PARENT-PARENTED CONVERSIONS
spn to plc to dyn multiple gr2
empty



SIMPLIFY THINGS FIRST (AVOID PARENTING TO EMPTIES,
OR EVEN TO EACH OTHER?, UNLESS IMPRESCINDIBLE. AIM
FOR THE MOST BASIC AND VISIBLE NON-ORGANIZATION)




loop jsons
    filter usable elements

    # pre-process dyn objects

    if "mag":
        replace swtor_filepath with mag .gr2's filepath

    elif "spn_p":
        check related plc
        if "dyn":
            ----------

        elif gr2.:
            replace swtor_filepath with mag .gr2's filepath






loop items:

    if "lit":
        # Lights
        CREATE LIGHT with name=swtor_id

    elif "hms":
        # Terrains
        IMPORT TERRAIN with name=swtor_id

    else:  # Objects
        if not duplicate:

            # turn indirect object refs to direct ones
            


            IMPORT OBJECTS


        else:  # is duplicate

            if meshes = 0:
                continue to next item

            DUPLICATE MESH OBJECT

            if meshes > 1:
                DUPLICATE REST OF MESH OBJECTS
                parent to first object




        if imported objects == 0:
            continue to next item

        if imported objects == 1:
            # single object
            continue to next item
        else:
            # multi-object
            prune colliders and others

            if more than 1 object left, select a parent or merge

    
    transformations
    custom props

parenting pass

renaming pass

final rotation

(final scaling if any)

tidying up
